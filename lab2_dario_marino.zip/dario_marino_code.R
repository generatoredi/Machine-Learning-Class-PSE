#1) Comparison of performances between ML techniques 
# it’s useless to check train dataset at this stage, 
# just check for the whole dataset get the lowest error for X/Y
# but we create train which could be useful for double

list.of.packages <- c("SuperLearner", "clusterGeneration", "mvtnorm", "xgboost")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages, repos = "http://cran.us.r-project.org")

invisible(lapply(list.of.packages, library, character.only = TRUE))

library(readr)
social_turnout <- read_csv("~/R/social_turnout.csv")


library(caret)
set.seed(123)
train_ind <- createDataPartition(social_turnout$outcome_voted, p = 0.75, list = FALSE)
train <- social_turnout[train_ind, ]
test <- social_turnout[-train_ind, ]

#let's move to different models for w on y and take the lowest risk


predictor_vars <- setdiff(names(social_turnout), c("outcome_voted", "treat_neighbors"))
pred2 <- setdiff(names(social_turnout), c("outcome_voted"))


sl_lm <- SuperLearner(Y = social_turnout$outcome_voted,
                      X = social_turnout[, predictor_vars],
                      family = binomial(),
                      SL.library = "SL.lm",
                      cvControl = list(V=5))

#Risk Coef
#SL.lm_All 0.1821044    1
#performs worst with gaussian

sl_glmnet <- SuperLearner(Y = social_turnout$outcome_voted,
                      X = social_turnout[, predictor_vars],
                      family = binomial(),
                      SL.library = "SL.glmnet",
                      cvControl = list(V=5))

#Risk Coef
#SL.glmnet_All 0.1858616    1


sl_xgb <- SuperLearner(Y = social_turnout$outcome_voted,
                          X = social_turnout[, predictor_vars],
                          family = binomial(),
                          SL.library = "SL.xgboost",
                          cvControl = list(V=5))


#Risk Coef
#SL.xgboost_All 0.1322723    1


sl_svm <- SuperLearner(Y = social_turnout$outcome_voted,
                          X = social_turnout[, predictor_vars],
                          family = binomial(),
                          SL.library = "SL.svm",
                          cvControl = list(V=5))


#Risk Coef
#SL.svm_All 0.1484119    1


#around 5 minutes each, svm longest one 20 minutes
#we decided to keep xgboost and raise cv to 5


#let's move to different models for w on x and take the lowest risk


sl_lm <- SuperLearner(Y = social_turnout$treat_neighbors,
                      X = social_turnout[, predictor_vars],
                      family = binomial(),
                      SL.library = "SL.lm",
                      cvControl = list(V=5))


#                Risk Coef
# SL.lm_All 0.07611536    1
#performs worst with gaussian

sl_glmnet <- SuperLearner(Y = social_turnout$treat_neighbors,
                      X = social_turnout[, predictor_vars],
                      family = binomial(),
                      SL.library = "SL.glmnet",
                      cvControl = list(V=5))

#Risk Coef
#SL.glmnet_All 0.06999605    1


sl_xgboost <- SuperLearner(Y = social_turnout$treat_neighbors,
                      X = social_turnout[, predictor_vars],
                      family = binomial(),
                      SL.library = "SL.xgboost",
                      cvControl = list(V=5))

#Risk Coef
#SL.xgboost_All 0.05893258    1

#we keep xgboost for both cases then


#test kernel just to see non linearities

sl_kernel <- SuperLearner(Y = social_turnout$outcome_voted,
                          X = social_turnout[, predictor_vars],
                          family = binomial(),
                          SL.library = "SL.kernelKnn",
                          cvControl = list(V=20))

#Risk Coef
#SL.kernelKnn_All 0.1397174    1
#fairly well but not as xgboost

sl_kernel <- SuperLearner(Y = social_turnout$treat_neighbors,
                          X = social_turnout[, predictor_vars],
                          family = binomial(),
                          SL.library = "SL.kernelKnn",
                          cvControl = list(V=5))
# SL.kernelKnn_All 0.06199557    1
#performs well but not as xgboost



#test nls for nonlinearities

sl_nnls <- SuperLearner(Y = social_turnout$outcome_voted,
                        X = social_turnout[, predictor_vars],
                        family = binomial(),
                        SL.library = "SL.nnls",
                        cvControl = list(V=5))
sl_nnls


#Risk Coef
#SL.nnls_All 15.60245    1
#not good as xgboost


sl_nnls <- SuperLearner(Y = social_turnout$treat_neighbors,
X = social_turnout[, predictor_vars],
family = binomial(),
SL.library = "SL.nnls",
cvControl = list(V=5))
sl_nnls

#Risk Coef
#SL.nnls_All 11.87817    1
#not good as xgboost


#2 Double ML and then estimate the beta (already 2 samples)

X=social_turnout$treat_neighbors
Y=social_turnout$outcome_voted
W=social_turnout[, predictor_vars]


doubleml <- function(X, W, Y, SL.library.X = "SL.xgboost",  SL.library.Y = "SL.xgboost", family.X = binomial(), family.Y = binomial()) {
  
  ### STEP 1: split X, W and Y into 2 random sets (done for you)
  split <- sample(seq_len(length(Y)), size = ceiling(length(Y)/2))
  
  Y1 = Y[split]
  Y2 = Y[-split]
  
  X1 = X[split]
  X2 = X[-split]
  
  W1 = W[split, ]
  W2 = W[-split, ]
  
  ### STEP 2a: use a SuperLearner to train a model for E[X|W] on set 1 and predict X on set 2 using this model. Do the same but training on set 2 and predicting on set 1
  
  sl_x1 = SuperLearner(Y = X1, 
                       X = data.frame(w=W1), # the data used to train the model
                       newX= data.frame(w=W2), # the data used to predict x
                       family = binomial(), 
                       SL.library = "SL.xgboost", # use whatever ML technique you like
                       cvControl = list(V=5)) 
  
  sl_x2 = SuperLearner(Y = X2, 
                       X = data.frame(w=W2), # the data used to train the model
                       newX= data.frame(w=W1), # the data used to predict x
                       family = binomial(), 
                       SL.library = "SL.xgboost", # use whatever ML technique you like
                       cvControl = list(V=5)) 
  
  
  ### STEP 2b: get the residuals X - X_hat on set 2 and on set 1
  
  x1_hat <-   sl_x1$SL.predict 
  x2_hat <-  sl_x2$SL.predict 
  
  
  ### STEP 3a: use a SuperLearner to train a model for E[Y|W] on set 1 and predict Y on set 2 using this model. Do the same but training on set 2 and predicting on set 1
  
  
  sl_y1 = SuperLearner(Y = Y1, 
                       X = data.frame(w=W1), # the data used to train the model
                       newX= data.frame(w=W2), # the data used to predict x
                       family = binomial(), 
                       SL.library = "SL.xgboost", # use whatever ML technique you like
                       cvControl = list(V=5)) 
  
  sl_y2 = SuperLearner(Y = Y2, 
                       X = data.frame(w=W2), # the data used to train the model
                       newX= data.frame(w=W1), # the data used to predict x
                       family = binomial(), 
                       SL.library = "SL.xgboost", # use whatever ML technique you like
                       cvControl = list(V=5)) 
  
  
  ### STEP 3b: get the residuals Y - Y_hat on set 2 and on set 1
  
  y1_hat <-   sl_y1$SL.predict 
  y2_hat <-  sl_y2$SL.predict 
  
  
  ### STEP 4: regress (Y - Y_hat) on (X - X_hat) on set 1 and on set 2, and get the coefficients of (X - X_hat)
  
  res_x1 =  X2-x1_hat  ## FILL HERE (residuals of prediction of x, i.e. true x - predicted x)
  res_y1 =  Y2-y1_hat  ## FILL HERE (residuals of prediction of y)
  
  res_x2 =  X1-x2_hat  ## FILL HERE (residuals of prediction of x, i.e. true x - predicted x)
  res_y2 =  Y1-y2_hat  ## FILL HERE (residuals of prediction of y)
  
  
  beta1 = (mean(res_x1*res_y1))/(mean(res_x1**2)) # (coefficient of regression of res_y on res_x)
  
  beta2 = (mean(res_x1*res_y1))/(mean(res_x1**2)) # (coefficient of regression of res_y on res_x)
  
  
  
  ### STEP 5: take the average of these 2 coefficients from the 2 sets (= beta)
  
  beta=mean(beta1,beta2)
  
  ### STEP 6: compute standard errors (done for you). This is just the usual OLS standard errors in the regression res_y = res_x*beta + eps. 
  
  psi_stack = c((res_y1-res_x1*beta), (res_y2-res_x2*beta))
  res_stack = c(res_x1, res_x2)
  se = sqrt(mean(res_stack^2)^(-2)*mean(res_stack^2*psi_stack^2))/sqrt(length(Y))
  
  return(c(beta,se))
}


doubleml(X, W, Y, SL.library.X = "SL.xgboost",  SL.library.Y = "SL.xgboost")

#without the X in the W (so controlled for X as in our code)
#we have:

#[1] 0.10235421 0.01609165

# meaning that by control for the demograpic characteristics
# that made more likely someone to vote, the effect of sending it
# was even larger, because this people were already
# predicted by their demographic to vote more



#[1] 0.08178880 0.01617508

# If we call instead of W=social_turnout[, predictor_vars]
# W= setdiff(names(social_turnout), c("outcome_voted"))
# we get 8 percent too
# this value however is measured if we keep the X in the W
# in the sense that we have X in the W so it is not controlled
# for the effect that W has on X




#4 Question 2 function (K) choose best one by 100 rerun


k2ml <- function(X, W, Y, K, SL.library.X = "SL.lm",  SL.library.Y = "SL.lm", family.X = gaussian(), family.Y = gaussian()) {
  
  
  #Merging Y,X and W into a list
  orig_list <- list(y=Y, x=X, w=W)
  
  #and then a DF:
  orig_df <- as.data.frame(orig_list)
  
  #Storing the number of columns, for later use
  num_col = ncol(orig_df)
  
  #Randomly Shuffling the Data
  orig_shufld <- orig_df[sample(nrow(orig_df)),]
  
  #Create 10 equally size folds
  folds <- cut(seq(1,nrow(orig_shufld)),breaks = K,labels=FALSE)
  
  #Creating Dummy vectors
  beta = rep(0, K)
  se = rep(0, K)
  psi <- c()
  res_x_all <- c()
  
  #Perform K fold cross validation
  for(i in 1:K){
    #Segment data by fold using the which() function 
    testIndexes <- which(folds==i,arr.ind=TRUE)
    testData <- orig_shufld[testIndexes, ]
    trainData <- orig_shufld[-testIndexes, ]
    
    ### STEP 2a: Using SuperLearner to train a model for E[X|W] on one fold and test on others
    sl_x = SuperLearner(Y = trainData$x,
                        X = trainData[,3:num_col],
                        newX= testData[,3:num_col],
                        family = family.X,
                        SL.library = SL.library.X,
                        cvControl = list(V=0))
    x_hat <- sl_x$SL.predict
    
    
    ## STEP 2b: getting residuals 
    res_x <- testData$x - x_hat
    
    ### STEP 3a: Using SuperLearner to train a model for E[Y|W] on one fold and test on others
    sl_y = SuperLearner(Y = trainData$y,
                        X = trainData[,3:num_col],
                        newX= testData[,3:num_col],
                        family =  family.Y,
                        SL.library =  SL.library.Y,
                        cvControl = list(V=0))
    y_hat <- sl_y$SL.predict
    
    
    ## STEP 3b: get the residuals
    res_y <- testData$y - y_hat
    
    ### STEP 4: regressing (Y - Y_hat) on (X - X_hat) on different sets
    beta[i] = (mean(res_x*res_y))/(mean(res_x*res_x))
    psi_i = (res_y-res_x*beta)
    psi <- c(psi, psi_i)
    res_x_all <- c(res_x_all, res_x)
    
  }
  
  #Taking an average of the K beta estimates
  mean_beta = mean(beta)
  
  #Computing OLS Standard Errors
  add <- 0
  for (i in 1:K) {
    add = add + mean(res_x_all[i]^2)^(-2)*mean(res_x_all[i]^2*psi[i]^2)
  }
  se = sqrt((1/K)*add)/sqrt(length(Y))
  
  return(c(mean_beta,se))
  
  
}

#we run the k2ml function

k2ml(X, W, Y,K=5, SL.library.X = "SL.xgboost",  SL.library.Y = "SL.xgboost")


#k2ml(X, W, Y,K=5, SL.library.X = "SL.xgboost",  SL.library.Y = "SL.xgboost")
#[1] 0.09044088 1.64134259
#looks good, a little below our 2 sample estimate
#here the sample is large so an higher cross validation
#would not increase problematically the variance
#we could say that this is a more accurate result
#but the highest effect compared on what the authors estimated
#is always there


#5 Comparison OLS with and without controlling for W



#ols run just between x and y

reg <- lm(social_turnout$outcome_voted~social_turnout$treat_neighbors,social_turnout)
reg

#Coefficients:
#  (Intercept)  social_turnout$treat_neighbors  
# 0.3595                          0.2655  

#simple OLS, with SL done for all the variables


#ols run between all the w+x and y as Y

#test performance

sl_lm2 <- SuperLearner(Y = social_turnout$outcome_voted,
                      X = social_turnout[,pred2],
                      family = binomial(),
                      SL.library = "SL.lm",
                      cvControl = list(V=20))


#actual formula

beta_X = c()

SL.library <- "SL.lm"
sl_lm <- SuperLearner(Y = social_turnout$outcome_voted,
                      X = social_turnout[,pred2],
                      family = binomial(),
                      SL.library = SL.library, 
                      cvControl = list(V=20))

beta_X = c(beta_X, coef(sl_lm$fitLibrary$SL.lm_All$object)[46])
beta_X

#treat_neighbors 
#0.1414814 



#comment the difference on the report (nonlinearities)

