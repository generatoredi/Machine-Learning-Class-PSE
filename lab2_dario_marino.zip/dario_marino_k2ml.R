k2ml <- function(X, W, Y, K, SL.library.X = "SL.lm",  SL.library.Y = "SL.lm", family.X = gaussian(), family.Y = gaussian()) {
  
  
  #Merging Y,X and W into a list
  orig_list <- list(y=Y, x=X, w=W)
  
  #and then a DF:
  orig_df <- as.data.frame(orig_list)
  
  #Storing the number of columns, for later use
  num_col = ncol(orig_df)
  
  #Randomly Shuffling the Data
  orig_shufld <- orig_df[sample(nrow(orig_df)),]
  
  #Create 10 equally size folds
  folds <- cut(seq(1,nrow(orig_shufld)),breaks = K,labels=FALSE)
  
  #Creating Dummy vectors
  beta = rep(0, K)
  se = rep(0, K)
  psi <- c()
  res_x_all <- c()
  
  #Perform K fold cross validation
  for(i in 1:K){
    #Segment data by fold using the which() function 
    testIndexes <- which(folds==i,arr.ind=TRUE)
    testData <- orig_shufld[testIndexes, ]
    trainData <- orig_shufld[-testIndexes, ]
    
    ### STEP 2a: Using SuperLearner to train a model for E[X|W] on one fold and test on others
    sl_x = SuperLearner(Y = trainData$x,
                        X = trainData[,3:num_col],
                        newX= testData[,3:num_col],
                        family = family.X,
                        SL.library = SL.library.X,
                        cvControl = list(V=0))
    x_hat <- sl_x$SL.predict
    
    
    ## STEP 2b: getting residuals 
    res_x <- testData$x - x_hat
    
    ### STEP 3a: Using SuperLearner to train a model for E[Y|W] on one fold and test on others
    sl_y = SuperLearner(Y = trainData$y,
                        X = trainData[,3:num_col],
                        newX= testData[,3:num_col],
                        family =  family.Y,
                        SL.library =  SL.library.Y,
                        cvControl = list(V=0))
    y_hat <- sl_y$SL.predict
    
    
    ## STEP 3b: get the residuals
    res_y <- testData$y - y_hat
    
    ### STEP 4: regressing (Y - Y_hat) on (X - X_hat) on different sets
    beta[i] = (mean(res_x*res_y))/(mean(res_x*res_x))
    psi_i = (res_y-res_x*beta)
    psi <- c(psi, psi_i)
    res_x_all <- c(res_x_all, res_x)
    
  }
  
  #Taking an average of the K beta estimates
  mean_beta = mean(beta)
  
  #Computing OLS Standard Errors
  add <- 0
  for (i in 1:K) {
    add = add + mean(res_x_all[i]^2)^(-2)*mean(res_x_all[i]^2*psi[i]^2)
  }
  se = sqrt((1/K)*add)/sqrt(length(Y))
  
  return(c(mean_beta,se))
  
  
}